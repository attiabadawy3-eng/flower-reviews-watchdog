
(function(){
"use strict";
var LOGO_DATA="./icon.svg";
function byId(id){return document.getElementById(id)}
var el={
 branch:byId("branch"),employee:byId("employee"),supplier:byId("supplier"),customName:byId("customName"),namePreview:byId("namePreview"),
 amount:byId("amount"),invoiceDate:byId("invoiceDate"),payment:byId("payment"),category:byId("category"),notes:byId("notes"),
 cameraInput:byId("cameraInput"),galleryInput:byId("galleryInput"),fileMeta:byId("fileMeta"),photoPreview:byId("photoPreview"),
 qualityNotice:byId("qualityNotice"),buildBtn:byId("buildBtn"),resetBtn:byId("resetBtn"),message:byId("message"),
 printArea:byId("printArea"),resultImage:byId("resultImage"),generatedName:byId("generatedName"),
 shareJpgBtn:byId("shareJpgBtn"),sharePdfBtn:byId("sharePdfBtn"),saveJpgBtn:byId("saveJpgBtn"),savePdfBtn:byId("savePdfBtn"),
 printBtn:byId("printBtn"),copyBtn:byId("copyBtn"),newBtn:byId("newBtn"),scrollTopBtn:byId("scrollTopBtn"),historyList:byId("historyList")
};
var sourceImage=null,sourceFileName="",jpgBlob=null,pdfBlob=null,jpgUrl="",pdfUrl="",jpgFilename="",pdfFilename="",summaryText="";
var STORAGE_PREF="flower_invoice_prefs_v3",STORAGE_HISTORY="flower_invoice_history_v3";

window.onerror=function(){
  showMessage("حدث خطأ داخلي في الصفحة. أعد فتح الرابط في Safari على iPhone أو Chrome على Android ثم حاول مرة أخرى.", "err");
  return false;
};

function storageGet(k){try{return window.localStorage?localStorage.getItem(k):null}catch(e){return null}}
function storageSet(k,v){try{if(window.localStorage)localStorage.setItem(k,v)}catch(e){}}
function safeJSON(s,f){try{return s?JSON.parse(s):f}catch(e){return f}}
function today(){
 var d=new Date(),m=("0"+(d.getMonth()+1)).slice(-2),day=("0"+d.getDate()).slice(-2);
 return d.getFullYear()+"-"+m+"-"+day;
}
function showMessage(t,type){el.message.className="notice show "+type;el.message.innerHTML=t}
function hideMessage(){el.message.className="notice";el.message.innerHTML=""}
function showQuality(t,type){el.qualityNotice.className="notice show "+type;el.qualityNotice.innerHTML=t}
function statusValue(){
 var r=document.getElementsByName("status"),i;
 for(i=0;i<r.length;i++){if(r[i].checked)return r[i].value}
 return "";
}
function branchParts(){
 var v=el.branch.value||"",p=v.split("|");
 return {code:p[0]||"",name:p[1]||""};
}
function money(v){
 var n=parseFloat(v); if(isNaN(n))n=0;
 return n.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g,",");
}
function cleanBaseName(s){
 return (s||"").replace(/\.(jpg|jpeg|png|pdf)$/i,"").replace(/[\\\/:*?"<>|]/g," ").replace(/\s+/g," ").trim();
}
function computeBaseName(){
 var c=cleanBaseName(el.customName.value);
 if(c)return c;
 var b=branchParts();
 var d=el.invoiceDate.value||today();
 var a=money(el.amount.value||0).replace(/,/g,"");
 var st=statusValue()==="مسددة"?"PAID":(statusValue()==="آجل"?"CREDIT":"UNPAID");
 return "FLOWER_"+b.code+"_"+d+"_"+a+"_"+st;
}
function updateNamePreview(){
 var base=computeBaseName();
 el.namePreview.innerHTML="اسم الملف المقترح: <b>"+escapeHtml(base)+".jpg</b> / <b>"+escapeHtml(base)+".pdf</b>";
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]})}
function savePrefs(){storageSet(STORAGE_PREF,JSON.stringify({branch:el.branch.value,employee:el.employee.value}))}
function loadPrefs(){
 var p=safeJSON(storageGet(STORAGE_PREF),{});
 if(p.branch)el.branch.value=p.branch;
 if(p.employee)el.employee.value=p.employee;
 el.invoiceDate.value=today();
}
function getHistory(){return safeJSON(storageGet(STORAGE_HISTORY),[])}
function addHistory(r){
 var h=getHistory();h.unshift(r);if(h.length>30)h=h.slice(0,30);
 storageSet(STORAGE_HISTORY,JSON.stringify(h));renderHistory();
}
function renderHistory(){
 var h=getHistory(),out="",i,r;
 if(!h.length){el.historyList.innerHTML='<div class="meta">لا توجد فواتير مسجلة على هذا الجهاز.</div>';return}
 for(i=0;i<Math.min(h.length,10);i++){r=h[i];out+='<div class="hist"><b>'+escapeHtml(r.branch)+" - "+escapeHtml(r.amount)+' ريال</b><div>'+escapeHtml(r.supplier)+" • "+escapeHtml(r.status)+" • "+escapeHtml(r.date)+" • "+escapeHtml(r.employee)+'</div></div>'}
 el.historyList.innerHTML=out;
}

function fileToImage(file){
 hideMessage();
 if(!file)return;
 if(file.type && file.type.indexOf("image/")!==0){showMessage("الملف المختار ليس صورة.", "err");return}
 var reader=new FileReader();
 reader.onerror=function(){showMessage("تعذر قراءة الصورة. جرّب صورة أخرى.", "err")};
 reader.onload=function(ev){
   var img=new Image();
   img.onload=function(){
     sourceImage=img;sourceFileName=file.name||"صورة الفاتورة";
     el.photoPreview.src=ev.target.result;el.photoPreview.style.display="block";
     var mb=(file.size/1024/1024).toFixed(1);
     el.fileMeta.innerHTML="<b>تم اختيار الصورة:</b> "+escapeHtml(sourceFileName)+"<br>"+img.naturalWidth+" × "+img.naturalHeight+" - "+mb+" MB";
     if(Math.min(img.naturalWidth,img.naturalHeight)<700)showQuality("الصورة منخفضة الدقة نسبيًا، لكن يمكن تجهيزها لأن بيانات المورد والمبلغ ستظهر منفصلة بوضوح.","warn");
     else showQuality("تم تحميل الصورة بنجاح. الصور الطويلة سيتم تصغيرها تلقائيًا داخل صفحة واحدة.","ok");
     showMessage("الصورة جاهزة. أكمل البيانات ثم اضغط «تجهيز الفاتورة».","ok");
   };
   img.onerror=function(){sourceImage=null;showMessage("المتصفح لم يستطع فتح هذه الصورة. إذا كانت HEIC جرّب التصوير مباشرة أو اختر JPG/PNG.","err")};
   img.src=ev.target.result;
 };
 reader.readAsDataURL(file);
}

function validate(){
 var miss=[],a=parseFloat(el.amount.value);
 if(!el.branch.value)miss.push("الفرع");
 if(!el.employee.value.trim())miss.push("اسم الموظف");
 if(!el.supplier.value.trim())miss.push("اسم المورد");
 if(isNaN(a)||a<=0)miss.push("المبلغ");
 if(!el.invoiceDate.value)miss.push("تاريخ الفاتورة");
 if(!el.payment.value)miss.push("طريقة السداد");
 if(!el.category.value)miss.push("نوع المصروف");
 if(!sourceImage)miss.push("صورة الفاتورة");
 if(miss.length){showMessage("أكمل البيانات التالية: <b>"+miss.join("، ")+"</b>","err");return false}
 return true;
}

function roundRect(ctx,x,y,w,h,r,fill,stroke){
 r=Math.min(r,w/2,h/2);ctx.beginPath();ctx.moveTo(x+r,y);ctx.arcTo(x+w,y,x+w,y+h,r);ctx.arcTo(x+w,y+h,x,y+h,r);ctx.arcTo(x,y+h,x,y,r);ctx.arcTo(x,y,x+w,y,r);ctx.closePath();
 if(fill){ctx.fillStyle=fill;ctx.fill()} if(stroke){ctx.strokeStyle=stroke;ctx.stroke()}
}
function wrap(ctx,text,maxWidth,maxLines){
 var words=String(text||"").split(/\s+/),lines=[],line="",i,test;
 for(i=0;i<words.length;i++){test=line?line+" "+words[i]:words[i];if(ctx.measureText(test).width<=maxWidth)line=test;else{if(line)lines.push(line);line=words[i];if(lines.length>=maxLines-1)break}}
 if(line&&lines.length<maxLines)lines.push(line);
 if(i<words.length-1&&lines.length){var last=lines.length-1;while(ctx.measureText(lines[last]+"…").width>maxWidth&&lines[last].length>2)lines[last]=lines[last].slice(0,-1);lines[last]+="…"}
 return lines;
}
function drawLabelValue(ctx,x,y,label,value,maxW,valueColor){
 ctx.textAlign="right";ctx.direction="rtl";ctx.fillStyle="#806d77";ctx.font="700 22px Tahoma, Arial";ctx.fillText(label,x,y);
 ctx.fillStyle=valueColor||"#251820";ctx.font="800 29px Tahoma, Arial";var lines=wrap(ctx,value,maxW,2),i;
 for(i=0;i<lines.length;i++)ctx.fillText(lines[i],x,y+37+i*33);
}

function canvasToBlob(canvas,type,quality,cb){
 if(canvas.toBlob){canvas.toBlob(function(b){if(b)cb(b);else cb(dataURLToBlob(canvas.toDataURL(type,quality)))},type,quality)}
 else cb(dataURLToBlob(canvas.toDataURL(type,quality)))
}
function dataURLToBlob(dataURL){
 var p=dataURL.split(","),mime=p[0].match(/:(.*?);/)[1],bin=atob(p[1]),len=bin.length,arr=new Uint8Array(len),i;
 for(i=0;i<len;i++)arr[i]=bin.charCodeAt(i);
 return new Blob([arr],{type:mime});
}
function blobToBytes(blob,cb){
 var r=new FileReader();r.onload=function(){cb(new Uint8Array(r.result))};r.readAsArrayBuffer(blob);
}
function makePdfFromJpeg(jpegBlob,imgW,imgH,cb){
 blobToBytes(jpegBlob,function(bytes){
   function ascii(s){
     var a=new Uint8Array(s.length),i;for(i=0;i<s.length;i++)a[i]=s.charCodeAt(i)&255;return a;
   }
   var parts=[],offsets=[0],pos=0;
   function add(x){parts.push(x);pos+=x.length}
   function str(s){add(ascii(s))}
   str("%PDF-1.4\n");
   offsets[1]=pos;str("1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n");
   offsets[2]=pos;str("2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n");
   offsets[3]=pos;str("3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>\nendobj\n");
   offsets[4]=pos;str("4 0 obj\n<< /Type /XObject /Subtype /Image /Width "+imgW+" /Height "+imgH+" /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length "+bytes.length+" >>\nstream\n");
   add(bytes);str("\nendstream\nendobj\n");
   var content="q\n595 0 0 842 0 0 cm\n/Im0 Do\nQ\n",contentBytes=ascii(content);
   offsets[5]=pos;str("5 0 obj\n<< /Length "+contentBytes.length+" >>\nstream\n");add(contentBytes);str("endstream\nendobj\n");
   var xref=pos;str("xref\n0 6\n0000000000 65535 f \n");
   var i,o;for(i=1;i<=5;i++){o=String(offsets[i]);while(o.length<10)o="0"+o;str(o+" 00000 n \n")}
   str("trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n"+xref+"\n%%EOF");
   cb(new Blob(parts,{type:"application/pdf"}));
 });
}

function build(){
 hideMessage();
 if(!validate())return;
 el.buildBtn.disabled=true;el.buildBtn.innerHTML="جاري التجهيز...";
 try{
   savePrefs();
   var b=branchParts(),status=statusValue(),amount=money(el.amount.value),supplier=el.supplier.value.trim(),employee=el.employee.value.trim(),custom=el.customName.value.trim();
   var W=1240,H=1754,canvas=document.createElement("canvas");canvas.width=W;canvas.height=H;
   var ctx=canvas.getContext("2d");if(!ctx)throw new Error("canvas");
   ctx.fillStyle="#f7f2f4";ctx.fillRect(0,0,W,H);
   var grad=ctx.createLinearGradient(0,0,W,220);grad.addColorStop(0,"#5b2038");grad.addColorStop(1,"#7a314d");ctx.fillStyle=grad;ctx.fillRect(0,0,W,220);
   ctx.fillStyle="#b79862";ctx.fillRect(0,212,W,8);
   var logo=new Image();
   logo.onload=function(){finishDraw(logo)};
   logo.onerror=function(){finishDraw(null)};
   logo.src=LOGO_DATA;

   function finishDraw(logoImg){
     try{
       if(logoImg){ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(W-110,105,68,0,Math.PI*2);ctx.fill();ctx.drawImage(logoImg,W-170,45,120,120)}
       ctx.textAlign="right";ctx.direction="rtl";ctx.fillStyle="#fff";ctx.font="800 47px Tahoma, Arial";ctx.fillText("تسجيل فاتورة فلور",W-215,88);
       ctx.font="700 30px Tahoma, Arial";ctx.fillStyle="rgba(255,255,255,.90)";ctx.fillText(b.name,W-215,136);
       ctx.font="500 23px Tahoma, Arial";ctx.fillStyle="rgba(255,255,255,.72)";ctx.fillText("FLOWER HOTEL",W-215,175);

       var y=244;
       if(custom){
         roundRect(ctx,60,y,W-120,92,18,"#fff","#eadfe4");ctx.fillStyle="#5b2038";ctx.font="800 29px Tahoma, Arial";ctx.textAlign="right";
         var titleLines=wrap(ctx,custom,W-180,2),ti;for(ti=0;ti<titleLines.length;ti++)ctx.fillText(titleLines[ti],W-90,y+40+ti*34);y+=112;
       }

       roundRect(ctx,60,y,W-120,404,20,"#fff","#eadfe4");
       var rx=W-92,lx=W/2-18,sy=y+54,colW=W/2-115;
       drawLabelValue(ctx,rx,sy,"المورد",supplier,colW,"#251820");
       drawLabelValue(ctx,lx,sy,"إجمالي الفاتورة",amount+" ريال",colW,"#5b2038");
       drawLabelValue(ctx,rx,sy+90,"حالة السداد",status,colW,status==="مسددة"?"#1f6b46":(status==="آجل"?"#93620e":"#9b2d30"));
       drawLabelValue(ctx,lx,sy+90,"طريقة السداد",el.payment.value,colW);
       drawLabelValue(ctx,rx,sy+180,"نوع المصروف",el.category.value,colW);
       drawLabelValue(ctx,lx,sy+180,"تاريخ الفاتورة",el.invoiceDate.value,colW);
       drawLabelValue(ctx,rx,sy+270,"الموظف",employee,colW);
       var now=new Date(),stamp=("0"+now.getDate()).slice(-2)+"/"+("0"+(now.getMonth()+1)).slice(-2)+"/"+now.getFullYear()+" "+("0"+now.getHours()).slice(-2)+":"+("0"+now.getMinutes()).slice(-2);
       drawLabelValue(ctx,lx,sy+270,"وقت التسجيل",stamp,colW);

       var imgTop=y+430,imgBottom=H-108,areaX=60,areaY=imgTop,areaW=W-120,areaH=imgBottom-imgTop;
       roundRect(ctx,areaX,areaY,areaW,areaH,18,"#fff","#eadfe4");
       var iw=sourceImage.naturalWidth||sourceImage.width,ih=sourceImage.naturalHeight||sourceImage.height;
       var scale=Math.min((areaW-28)/iw,(areaH-28)/ih),dw=Math.max(1,Math.round(iw*scale)),dh=Math.max(1,Math.round(ih*scale));
       var dx=areaX+(areaW-dw)/2,dy=areaY+(areaH-dh)/2;
       ctx.drawImage(sourceImage,0,0,iw,ih,dx,dy,dw,dh);

       ctx.fillStyle="#b79862";ctx.fillRect(60,H-82,W-120,2);ctx.textAlign="center";ctx.direction="rtl";ctx.fillStyle="#75656d";ctx.font="700 20px Tahoma, Arial";
       ctx.fillText("صورة الفاتورة كاملة داخل صفحة واحدة - البيانات أعلاه مدخلة بواسطة الموظف",W/2,H-44);

       canvasToBlob(canvas,"image/jpeg",0.88,function(blob){
         jpgBlob=blob;
         if(jpgUrl)URL.revokeObjectURL(jpgUrl);
         jpgUrl=URL.createObjectURL(blob);
         var base=computeBaseName();jpgFilename=base+".jpg";pdfFilename=base+".pdf";
         el.resultImage.src=jpgUrl;el.generatedName.innerHTML="اسم الملف الكامل:<br><b>"+escapeHtml(jpgFilename)+"</b><br><b>"+escapeHtml(pdfFilename)+"</b>";
         summaryText=(custom?"اسم الفاتورة: "+custom+"\n":"")+b.name+"\nالمورد: "+supplier+"\nالمبلغ: "+amount+" ريال\nالحالة: "+status+"\nطريقة السداد: "+el.payment.value+"\nنوع المصروف: "+el.category.value+"\nالتاريخ: "+el.invoiceDate.value+"\nالموظف: "+employee+(el.notes.value.trim()?"\nملاحظة: "+el.notes.value.trim():"");
         makePdfFromJpeg(blob,W,H,function(pblob){
           pdfBlob=pblob;if(pdfUrl)URL.revokeObjectURL(pdfUrl);pdfUrl=URL.createObjectURL(pblob);
           el.printArea.className="card result show";
           el.buildBtn.disabled=false;el.buildBtn.innerHTML="تجهيز الفاتورة";
           showMessage("تم تجهيز الفاتورة بنجاح كصورة JPG وملف PDF، وكلاهما صفحة واحدة.","ok");
           addHistory({branch:b.name,amount:amount,supplier:supplier,status:status,date:el.invoiceDate.value,employee:employee});
           setTimeout(function(){el.printArea.scrollIntoView()},50);
         });
       });
     }catch(ex){
       el.buildBtn.disabled=false;el.buildBtn.innerHTML="تجهيز الفاتورة";showMessage("تعذر تجهيز الفاتورة على هذا الجهاز. أعد فتح الرابط في Safari أو Chrome ثم حاول مرة أخرى.","err");
     }
   }
 }catch(e){
   el.buildBtn.disabled=false;el.buildBtn.innerHTML="تجهيز الفاتورة";showMessage("تعذر تجهيز الفاتورة. تأكد من اختيار صورة ثم أعد المحاولة.","err");
 }
}
function downloadBlob(blob,name){
 if(!blob)return;var u=URL.createObjectURL(blob),a=document.createElement("a");a.href=u;a.download=name;document.body.appendChild(a);a.click();setTimeout(function(){document.body.removeChild(a);URL.revokeObjectURL(u)},1000);
}
function shareBlob(blob,name,mime){
 if(!blob)return;
 var f;
 try{f=new File([blob],name,{type:mime})}catch(e){downloadBlob(blob,name);return}
 if(navigator.share){
   var data={title:cleanBaseName(el.customName.value)||"فاتورة فلور",text:summaryText,files:[f]};
   if(!navigator.canShare || navigator.canShare({files:[f]})){
     navigator.share(data).catch(function(err){if(!err||err.name!=="AbortError")showMessage("تعذرت المشاركة المباشرة. تم تجهيز الملف ويمكن حفظه ثم إرساله على واتساب.","warn")});
     return;
   }
 }
 downloadBlob(blob,name);showMessage("المشاركة المباشرة غير مدعومة في هذا المتصفح. تم تنزيل الملف؛ افتح واتساب وأرسله للجروب.","warn");
}
function resetForm(){
 el.supplier.value="";el.customName.value="";el.amount.value="";el.invoiceDate.value=today();el.payment.value="";el.category.value="";el.notes.value="";
 byId("unpaid").checked=true;el.cameraInput.value="";el.galleryInput.value="";sourceImage=null;sourceFileName="";el.photoPreview.style.display="none";el.photoPreview.removeAttribute("src");
 el.fileMeta.innerHTML="لم يتم اختيار صورة.";el.qualityNotice.className="notice";el.qualityNotice.innerHTML="";el.printArea.className="card result";hideMessage();updateNamePreview();window.scrollTo(0,0);
}
function copyText(){
 var ta=document.createElement("textarea");ta.value=summaryText;document.body.appendChild(ta);ta.select();try{document.execCommand("copy");showMessage("تم نسخ بيانات الفاتورة.","ok")}catch(e){showMessage("تعذر النسخ التلقائي.","warn")}document.body.removeChild(ta);
}

el.cameraInput.addEventListener("change",function(){fileToImage(el.cameraInput.files&&el.cameraInput.files[0])});
el.galleryInput.addEventListener("change",function(){fileToImage(el.galleryInput.files&&el.galleryInput.files[0])});
el.buildBtn.addEventListener("click",build);
el.resetBtn.addEventListener("click",resetForm);el.newBtn.addEventListener("click",resetForm);
el.shareJpgBtn.addEventListener("click",function(){shareBlob(jpgBlob,jpgFilename,"image/jpeg")});
el.sharePdfBtn.addEventListener("click",function(){shareBlob(pdfBlob,pdfFilename,"application/pdf")});
el.saveJpgBtn.addEventListener("click",function(){downloadBlob(jpgBlob,jpgFilename)});
el.savePdfBtn.addEventListener("click",function(){downloadBlob(pdfBlob,pdfFilename)});
el.printBtn.addEventListener("click",function(){window.print()});
el.copyBtn.addEventListener("click",copyText);
el.scrollTopBtn.addEventListener("click",function(){window.scrollTo(0,0)});
el.customName.addEventListener("input",updateNamePreview);el.branch.addEventListener("change",function(){savePrefs();updateNamePreview()});el.employee.addEventListener("change",savePrefs);el.amount.addEventListener("input",updateNamePreview);el.invoiceDate.addEventListener("change",updateNamePreview);
var radios=document.getElementsByName("status"),ri;for(ri=0;ri<radios.length;ri++)radios[ri].addEventListener("change",function(){if(statusValue()!=="مسددة")el.payment.value="لم تسدد";else if(el.payment.value==="لم تسدد")el.payment.value="";updateNamePreview()});
loadPrefs();renderHistory();updateNamePreview();
})();

if ("serviceWorker" in navigator && location.protocol === "https:") {
  window.addEventListener("load", function () {
    navigator.serviceWorker.register("./sw.js").catch(function(){});
  });
}
