(() => {
  const FEED = "https://raw.githubusercontent.com/attiabadawy3-eng/flower-reviews-watchdog/main/public/reviews-summary.json";
  const ids = ["flower-1", "flower-2", "flower-3", "flower-4"];
  const lang = (document.documentElement.lang || "").toLowerCase().startsWith("en") ? "en" : "ar";

  const formatNumber = (n) => new Intl.NumberFormat("en-US", { maximumFractionDigits: 0 }).format(n);
  const formatRating = (n) => Number(n).toFixed(1);
  const formatVerified = (iso) => {
    try {
      return new Intl.DateTimeFormat(lang === "en" ? "en-GB" : "ar-EG-u-nu-latn", {
        timeZone: "Asia/Riyadh",
        day: "numeric",
        month: "long",
        year: "numeric",
        hour: "numeric",
        minute: "2-digit"
      }).format(new Date(iso));
    } catch {
      return iso;
    }
  };
  const setText = (selector, value) => document.querySelectorAll(selector).forEach((el) => { el.textContent = value; });

  function apply(doc) {
    if (!doc || doc.schemaVersion !== 1 || !doc.branches || !doc.verifiedAt) throw new Error("invalid review feed");
    for (const id of ids) {
      const b = doc.branches[id];
      if (!b || !Number.isFinite(Number(b.rating)) || !Number.isInteger(Number(b.reviewCount))) continue;
      const rating = formatRating(b.rating);
      const count = formatNumber(b.reviewCount);
      setText('[data-google-rating="' + id + '"]', rating);
      setText('[data-google-review-count="' + id + '"]', count);
      setText('[data-google-card="' + id + '"]', "★ " + rating + " · " + count + " Google");
      document.querySelectorAll('[data-google-review-summary="' + id + '"]').forEach((el) => {
        el.textContent = lang === "en"
          ? count + " Google reviews for this branch. Last verified: "
          : count + " مراجعة على Google لهذا الفرع. آخر تحقق: ";
        const time = document.createElement("time");
        time.setAttribute("data-google-verified", "");
        time.textContent = formatVerified(doc.verifiedAt);
        el.appendChild(time);
        el.append(".");
      });
    }
    setText("[data-google-verified]", formatVerified(doc.verifiedAt));

    const ageMs = Date.now() - new Date(doc.verifiedAt).getTime();
    const fresh = Number.isFinite(ageMs) && ageMs >= 0 && ageMs <= 36 * 60 * 60 * 1000;
    document.documentElement.dataset.googleReviews = fresh ? "fresh" : "stale";
    document.querySelectorAll("[data-google-status]").forEach((el) => {
      el.textContent = fresh
        ? (lang === "en" ? "Google data updates automatically" : "تُحدّث بيانات Google تلقائيًا")
        : (lang === "en" ? "Showing the last verified Google data" : "نعرض آخر بيانات Google تم التحقق منها");
    });
  }

  async function load() {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000);
    try {
      const bucket = Math.floor(Date.now() / 300000);
      const res = await fetch(FEED + "?v=" + bucket, { cache: "no-store", mode: "cors", signal: controller.signal });
      if (!res.ok) throw new Error("review feed " + res.status);
      apply(await res.json());
    } catch (err) {
      document.documentElement.dataset.googleReviews = "fallback";
      console.warn("[FLOWER] Google review feed fallback", err);
    } finally {
      clearTimeout(timeout);
    }
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", load, { once: true });
  else load();
})();