(() => {
  'use strict';
  const qs=(s,r=document)=>r.querySelector(s), qsa=(s,r=document)=>[...r.querySelectorAll(s)];
  const isEn=document.documentElement.lang==='en';
  const body=document.body;
  const escText=s=>String(s??'').trim();
  const currentSrc=img=>img?.currentSrc||img?.src||'';
  const booking=qs('.v7-booking-form');
  const fields=booking?{
    branch:qs('#book-branch',booking),unit:qs('#book-unit',booking),arrival:qs('#book-arrival',booking),
    departure:qs('#book-departure',booking),adults:qs('#book-adults',booking),children:qs('#book-children',booking)
  }:null;
  const branchInfo=()=>{
    const o=fields?.branch?.options[fields.branch.selectedIndex];
    return {label:o?.textContent.trim()||'',phone:(o?.dataset.phone||'').replace(/\D/g,'')};
  };
  const whatsappFor=unit=>{
    const b=branchInfo(); if(!b.phone)return '#';
    const propertyName=escText(qs('.v10-property-info h1')?.textContent)||b.label;
    const msg=isEn
      ?`Hello, I would like to enquire about ${unit} at ${propertyName}.\nArrival: ${fields?.arrival?.value||'-'}\nDeparture: ${fields?.departure?.value||'-'}\nAdults: ${fields?.adults?.value||'-'}\nChildren: ${fields?.children?.value||'-'}`
      :`السلام عليكم، أرغب في الاستفسار عن وحدة ${unit} في ${propertyName}.\nالدخول: ${fields?.arrival?.value||'-'}\nالخروج: ${fields?.departure?.value||'-'}\nالبالغون: ${fields?.adults?.value||'-'}\nالأطفال: ${fields?.children?.value||'-'}`;
    return `https://wa.me/${b.phone}?text=${encodeURIComponent(msg)}`;
  };
  function enhanceGallery(){
    const gallery=qs('.v7-gallery'); if(!gallery)return; const dialog=qs('#gallery-dialog',gallery); if(!dialog)return;
    dialog.classList.add('v11-lightbox');
    const main=qs('figure img',dialog), counter=qs('.v7-lightbox-counter',dialog);
    const prev=qs('.v7-lightbox-prev',dialog), next=qs('.v7-lightbox-next',dialog);
    const chrome=document.createElement('div'); chrome.className='v11-lightbox-chrome';
    chrome.innerHTML=`<div class="v11-lightbox-title"><span>${isEn?'FLOWER GALLERY':'معرض فلور'}</span><strong class="v11-lightbox-category"></strong></div><div class="v11-lightbox-thumbs" role="list"></div>`;
    dialog.appendChild(chrome);
    const cat=qs('.v11-lightbox-category',chrome), thumbs=qs('.v11-lightbox-thumbs',chrome);
    let index=0,startX=null,savedScroll=0;
    const visible=()=>qsa('.v7-gallery-item',gallery).filter(x=>!x.hidden).sort((a,b)=>(Number(a.style.order||9999)-Number(b.style.order||9999)));
    const paint=()=>{
      const list=visible(); thumbs.innerHTML='';
      list.forEach((item,i)=>{const im=qs('img',item),b=document.createElement('button'); b.type='button'; b.className='v11-thumb'+(i===index?' is-active':''); b.setAttribute('aria-label',`${i+1}`); b.innerHTML=`<img src="${currentSrc(im)}" alt="">`; b.querySelector('img').alt=im?.alt||'FLOWER'; b.addEventListener('click',e=>{e.preventDefault();show(i,false)}); thumbs.appendChild(b)});
      if(dialog.open) qs('.v11-thumb.is-active',thumbs)?.scrollIntoView({block:'nearest',inline:'center'});
    };
    const show=(i,open=true)=>{
      const opening=open&&!dialog.open; if(opening)savedScroll=window.scrollY;
      const list=visible(); if(!list.length)return; index=(i+list.length)%list.length;
      const item=list[index],im=qs('img',item); main.src=currentSrc(im); main.alt=im?.alt||'FLOWER';
      counter.textContent=`${index+1} / ${list.length}`; cat.textContent=qs('span',item)?.textContent||''; paint();
      if(opening)dialog.showModal(); body.classList.add('v11-modal-open');
    };
    gallery.addEventListener('click',e=>{const item=e.target.closest('.v7-gallery-item');if(!item||!gallery.contains(item))return;e.preventDefault();e.stopImmediatePropagation();const list=visible();show(list.indexOf(item),true)},{capture:true});
    prev?.addEventListener('click',e=>{e.preventDefault();e.stopImmediatePropagation();show(index-1,false)},{capture:true});
    next?.addEventListener('click',e=>{e.preventDefault();e.stopImmediatePropagation();show(index+1,false)},{capture:true});
    dialog.addEventListener('close',()=>{body.classList.remove('v11-modal-open');const root=document.documentElement,prev=root.style.scrollBehavior,restore=()=>window.scrollTo(0,savedScroll);root.style.scrollBehavior='auto';restore();setTimeout(restore,0);setTimeout(restore,50);setTimeout(()=>{restore();root.style.scrollBehavior=prev},120)});
    dialog.addEventListener('keydown',e=>{if(e.key==='ArrowRight'){e.preventDefault();show(index+1,false)}else if(e.key==='ArrowLeft'){e.preventDefault();show(index-1,false)}});
    dialog.addEventListener('touchstart',e=>{startX=e.touches[0]?.clientX??null},{passive:true,capture:true});
    dialog.addEventListener('touchend',e=>{if(startX==null)return;const x=e.changedTouches[0]?.clientX??startX;if(Math.abs(x-startX)>45){e.stopImmediatePropagation();show(index+(x<startX?1:-1),false)}startX=null},{passive:true,capture:true});
    qs('.v7-gallery-filters',gallery)?.addEventListener('click',e=>{const f=e.target.closest('.v7-gallery-filter');if(!f)return;setTimeout(()=>{qsa('.v7-gallery-filter',gallery).forEach(x=>x.classList.toggle('is-active',x===f));const fc=f.dataset.galleryFilter;qsa('.v7-gallery-item',gallery).forEach(item=>item.hidden=!(fc==='all'||item.dataset.galleryCat===fc));index=0;paint()},0)});
    window.addEventListener('flowercms:ready',()=>{const list=visible();index=Math.min(index,Math.max(0,list.length-1));if(dialog.open)show(index,false);else paint()});
  }

  function enhanceUnitDialogs(){
    qsa('.v7-unit-dialog').forEach(dialog=>{
      const sourceGallery=qs('.v7-unit-dialog-gallery',dialog); if(!sourceGallery)return;
      const photos=()=>[...sourceGallery.children].filter(x=>x.tagName==='IMG').sort((a,b)=>(Number(a.dataset.flowerOrder||9999)-Number(b.dataset.flowerOrder||9999))); if(!photos().length)return;
      const title=escText(qs('h2',dialog)?.textContent), enquire=qs('.v7-unit-enquire',dialog);
      let current=0;
      sourceGallery.classList.add('v11-unit-gallery');
      const mainWrap=document.createElement('div'); mainWrap.className='v11-unit-main-wrap';
      mainWrap.innerHTML=`<button type="button" class="v11-unit-nav v11-unit-prev" aria-label="${isEn?'Previous photo':'الصورة السابقة'}">‹</button><img class="v11-unit-main" alt=""><button type="button" class="v11-unit-nav v11-unit-next" aria-label="${isEn?'Next photo':'الصورة التالية'}">›</button><span class="v11-unit-counter"></span>`;
      sourceGallery.prepend(mainWrap);
      const strip=document.createElement('div'); strip.className='v11-unit-thumbs'; sourceGallery.appendChild(strip);
      const main=qs('.v11-unit-main',mainWrap), count=qs('.v11-unit-counter',mainWrap);
      const render=()=>{const sourceImages=photos();if(!sourceImages.length)return;current=Math.min(current,sourceImages.length-1);strip.innerHTML='';sourceImages.forEach((im,i)=>{const b=document.createElement('button');b.type='button';b.className='v11-unit-thumb'+(i===current?' is-active':'');b.innerHTML=`<img src="${currentSrc(im)}" alt="">`;b.querySelector('img').alt=im?.alt||title||'FLOWER';b.addEventListener('click',()=>{current=i;render()});strip.appendChild(b)});main.src=currentSrc(sourceImages[current]);main.alt=sourceImages[current]?.alt||title;count.textContent=`${current+1} / ${sourceImages.length}`};
      const move=n=>{const sourceImages=photos();if(!sourceImages.length)return;current=(current+n+sourceImages.length)%sourceImages.length;render()};
      qs('.v11-unit-prev',mainWrap)?.addEventListener('click',()=>move(-1));
      qs('.v11-unit-next',mainWrap)?.addEventListener('click',()=>move(1));
      photos().forEach(im=>im.classList.add('v11-source-photo'));
      const info=qs('.v7-unit-dialog-inner > div:last-child',dialog);
      const policies=document.createElement('div'); policies.className='v11-unit-policies';
      policies.innerHTML=isEn
        ?`<div><span>Check-in</span><strong>4:00 PM</strong></div><div><span>Check-out</span><strong>2:00 PM next day</strong></div><div><span>Children</span><strong>Allowed</strong></div><div><span>Cancellation</span><strong>No refund</strong></div>`
        :`<div><span>الدخول</span><strong>4:00 م</strong></div><div><span>الخروج</span><strong>2:00 م من اليوم التالي</strong></div><div><span>الأطفال</span><strong>مسموح</strong></div><div><span>الإلغاء</span><strong>لا يوجد استرداد</strong></div>`;
      const direct=document.createElement('a'); direct.className='btn v11-unit-whatsapp'; direct.target='_blank'; direct.rel='noopener'; direct.textContent=isEn?'Enquire about this unit on WhatsApp':'استفسر عن هذه الوحدة عبر واتساب';
      info?.insertBefore(policies,enquire||null); enquire?.insertAdjacentElement('afterend',direct);
      const syncWa=()=>{const valid=window.FLOWER_BOOKING_DATES_VALID;direct.href=(typeof valid==='function'&&valid())?whatsappFor(enquire?.dataset.unitValue||title):'#'};
      direct.addEventListener('click',e=>{const validate=window.FLOWER_BOOKING_VALIDATE;if(typeof validate==='function'&&!validate()){e.preventDefault();e.stopPropagation()}});
      dialog.addEventListener('close',()=>{body.classList.remove('v11-modal-open');const root=document.documentElement,prev=root.style.scrollBehavior,restore=()=>window.scrollTo(0,savedScroll);root.style.scrollBehavior='auto';restore();setTimeout(restore,0);setTimeout(restore,50);setTimeout(()=>{restore();root.style.scrollBehavior=prev},120)});
      dialog.addEventListener('keydown',e=>{if(e.key==='ArrowRight')move(1);else if(e.key==='ArrowLeft')move(-1)});
      dialog.addEventListener('toggle',()=>{if(dialog.open){render();syncWa()}});
      qsa(`[data-unit-dialog="${dialog.id}"]`).forEach(btn=>btn.addEventListener('click',()=>setTimeout(()=>{body.classList.add('v11-modal-open');render();syncWa()},0)));
      window.addEventListener('flowercms:ready',()=>{photos().forEach(im=>im.classList.add('v11-source-photo'));render()}); render(); syncWa();
    });
  }
  function enhanceBooking(){
    if(!booking||!fields)return; booking.classList.add('v11-booking-form');
    const context=document.createElement('div'); context.className='v12-booking-context'; booking.appendChild(context);
    const update=()=>{const b=branchInfo();const total=(Number(fields.adults.value)||0)+(Number(fields.children.value)||0);context.innerHTML=isEn
      ?`<span>Enquiry goes to</span><strong>${b.label}</strong><small>${fields.unit.value} · ${fields.arrival.value} → ${fields.departure.value} · ${total} guests</small>`
      :`<span>سيُرسل الاستفسار إلى</span><strong>${b.label}</strong><small>${fields.unit.value} · ${fields.arrival.value} ← ${fields.departure.value} · ${total} ضيوف</small>`;};
    Object.values(fields).forEach(el=>el?.addEventListener('change',update)); update();
  }

  function enhanceMotion(){
    const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
    const sections=qsa('.v7-section,.v7-booking,.v8-about,.v8-similar,.v7-final-cta');
    sections.forEach(x=>x.classList.add('v11-reveal'));
    if(reduced){sections.forEach(x=>x.classList.add('is-visible'));return;}
    const io=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('is-visible');io.unobserve(e.target)}}),{threshold:.08,rootMargin:'0px 0px -40px'});
    sections.forEach(x=>io.observe(x));
    const tabs=qsa('.v8-tabbar a');
    const targets=tabs.map(a=>qs(a.getAttribute('href'))).filter(Boolean);
    const tio=new IntersectionObserver(entries=>entries.forEach(e=>{if(!e.isIntersecting)return;tabs.forEach(a=>a.classList.toggle('is-active',a.getAttribute('href')===`#${e.target.id}`))}),{rootMargin:'-30% 0px -62%',threshold:0});
    targets.forEach(x=>tio.observe(x));
  }

  document.addEventListener('DOMContentLoaded',()=>{enhanceGallery();enhanceUnitDialogs();enhanceBooking();enhanceMotion();});
})();
