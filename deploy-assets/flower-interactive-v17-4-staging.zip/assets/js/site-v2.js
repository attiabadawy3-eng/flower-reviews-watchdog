(() => {
  const body = document.body;
  if (!body.classList.contains('v7')) return;
  const menuButton = document.querySelector('.v7-menu');
  const nav = document.querySelector('#main-nav');
  const closeMenu = () => { nav?.classList.remove('open'); menuButton?.setAttribute('aria-expanded','false'); };
  menuButton?.addEventListener('click', () => {
    const open = nav?.classList.toggle('open');
    menuButton.setAttribute('aria-expanded', String(Boolean(open)));
  });
  nav?.addEventListener('click', e => { if (e.target.closest('a')) closeMenu(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeMenu(); });
  window.addEventListener('resize', () => { if (window.innerWidth > 900) closeMenu(); });

  const branchSwitch = document.querySelector('#site-branch-switch');
  branchSwitch?.addEventListener('change', () => {
    if (branchSwitch.value) window.location.href = branchSwitch.value;
  });
})();

(() => {
  const form = document.querySelector('.v7-booking-form');
  if (!form) return;
  const branch = form.querySelector('#book-branch');
  const unit = form.querySelector('#book-unit');
  const arrival = form.querySelector('#book-arrival');
  const departure = form.querySelector('#book-departure');
  const adults = form.querySelector('#book-adults');
  const children = form.querySelector('#book-children');
  const wa = form.querySelector('#book-whatsapp');
  const booking = form.querySelector('#book-booking');
  const isEn = form.dataset.lang === 'en';
  const toISO = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  const today = new Date(); today.setHours(12,0,0,0);
  const tomorrow = new Date(today); tomorrow.setDate(today.getDate()+1);
  arrival.min = toISO(today); departure.min = toISO(tomorrow);
  if (!arrival.value) arrival.value = toISO(today);
  if (!departure.value) departure.value = toISO(tomorrow);

  const normalizeDates = () => {
    if (!arrival.value) return;
    const next = new Date(arrival.value + 'T12:00:00'); next.setDate(next.getDate()+1);
    departure.min = toISO(next);
    if (!departure.value || departure.value <= arrival.value) departure.value = toISO(next);
  };
  const clearDateValidity = () => { arrival.setCustomValidity(''); departure.setCustomValidity(''); };
  const datesAreSane = () => {
    const todayISO = toISO(today);
    return Boolean(arrival.value && departure.value && arrival.value >= todayISO && departure.value > arrival.value);
  };
  const validateDates = () => {
    clearDateValidity();
    const todayISO = toISO(today);
    if (!arrival.value || arrival.value < todayISO) {
      arrival.setCustomValidity(isEn ? 'Please choose today or a future arrival date.' : 'يرجى اختيار تاريخ وصول اليوم أو تاريخ لاحق.');
      arrival.reportValidity(); arrival.focus(); return false;
    }
    if (!departure.value || departure.value <= arrival.value) {
      departure.setCustomValidity(isEn ? 'Departure must be after arrival.' : 'يجب أن يكون تاريخ المغادرة بعد تاريخ الوصول.');
      departure.reportValidity(); departure.focus(); return false;
    }
    return true;
  };
  window.FLOWER_BOOKING_VALIDATE = validateDates;
  window.FLOWER_BOOKING_DATES_VALID = datesAreSane;
  const sync = () => {
    normalizeDates();
    const option = branch.options[branch.selectedIndex];
    const phone = (option?.dataset.phone || '').replace(/\D/g,'');
    const branchLabel = option?.textContent.trim() || '';
    const message = isEn
      ? `Hello, I would like to enquire about availability at FLOWER ${branchLabel}.\nUnit: ${unit.value}\nArrival: ${arrival.value}\nDeparture: ${departure.value}\nAdults: ${adults.value}\nChildren: ${children.value}`
      : `السلام عليكم، أرغب في الاستفسار عن التوفر في فلور ${branchLabel}.\nنوع الوحدة: ${unit.value}\nالوصول: ${arrival.value}\nالمغادرة: ${departure.value}\nالبالغون: ${adults.value}\nالأطفال: ${children.value}`;
    if (datesAreSane()) {
      wa.href = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
      wa.removeAttribute('aria-disabled');
    } else {
      wa.href = '#';
      wa.setAttribute('aria-disabled','true');
    }
    booking.href = option?.dataset.booking || '#';
  };
  [branch,unit,arrival,departure,adults,children].forEach(el => el?.addEventListener('change',sync));
  arrival?.addEventListener('input', () => arrival.setCustomValidity(''));
  departure?.addEventListener('input', () => departure.setCustomValidity(''));
  wa?.addEventListener('click', e => {
    sync();
    if (!validateDates()) { e.preventDefault(); e.stopPropagation(); }
  });
  sync();

  document.querySelectorAll('.v7-unit-enquire').forEach(btn => {
    btn.addEventListener('click', () => {
      const value = btn.dataset.unitValue;
      [...unit.options].forEach((o,i) => { if (o.value === value) unit.selectedIndex = i; });
      btn.closest('dialog')?.close();
      unit.dispatchEvent(new Event('change',{bubbles:true}));
      document.querySelector('#booking')?.scrollIntoView({behavior:'smooth',block:'start'});
    });
  });
})();

(() => {
  document.querySelectorAll('.v7-unit-detail').forEach(btn => {
    btn.addEventListener('click', () => {
      const dialog = document.getElementById(btn.dataset.unitDialog);
      if (dialog?.showModal) dialog.showModal();
    });
  });
  document.querySelectorAll('.v7-unit-dialog').forEach(dialog => {
    dialog.querySelector('.v7-dialog-close')?.addEventListener('click', () => dialog.close());
    dialog.addEventListener('click', e => { if (e.target === dialog) dialog.close(); });
  });
})();

(() => {
  const gallery = document.querySelector('.v7-gallery');
  if (!gallery) return;
  const items = [...gallery.querySelectorAll('.v7-gallery-item')];
  const filters = [...gallery.querySelectorAll('.v7-gallery-filter')];
  const dialog = gallery.querySelector('#gallery-dialog');
  const image = dialog?.querySelector('img');
  const counter = dialog?.querySelector('.v7-lightbox-counter');
  const prev = dialog?.querySelector('.v7-lightbox-prev');
  const next = dialog?.querySelector('.v7-lightbox-next');
  let current = 0;
  const visible = () => items.filter(x => !x.hidden);
  const show = item => {
    const list = visible();
    current = Math.max(0,list.indexOf(item));
    const active = list[current] || item;
    const liveImg = active.querySelector('img');
    image.src = liveImg?.currentSrc || liveImg?.src || active.dataset.gallerySrc;
    image.alt = liveImg?.alt || 'FLOWER';
    counter.textContent = `${current + 1} / ${list.length}`;
  };
  items.forEach(item => item.addEventListener('click', () => {
    show(item); if (dialog?.showModal) dialog.showModal();
  }));
  filters.forEach(filter => filter.addEventListener('click', () => {
    filters.forEach(x => x.classList.toggle('is-active',x === filter));
    const cat = filter.dataset.galleryFilter;
    items.forEach(item => item.hidden = !(cat === 'all' || item.dataset.galleryCat === cat));
  }));
  const move = step => {
    const list = visible(); if (!list.length) return;
    current = (current + step + list.length) % list.length;
    show(list[current]);
  };
  prev?.addEventListener('click', () => move(-1));
  next?.addEventListener('click', () => move(1));
  dialog?.querySelector('.v7-dialog-close')?.addEventListener('click', () => dialog.close());
  dialog?.addEventListener('click', e => { if (e.target === dialog) dialog.close(); });
  let startX = null;
  dialog?.addEventListener('touchstart', e => { startX = e.touches[0]?.clientX ?? null; }, {passive:true});
  dialog?.addEventListener('touchend', e => {
    if (startX == null) return;
    const endX = e.changedTouches[0]?.clientX ?? startX;
    if (Math.abs(endX - startX) > 45) move(endX < startX ? 1 : -1);
    startX = null;
  }, {passive:true});
})();
